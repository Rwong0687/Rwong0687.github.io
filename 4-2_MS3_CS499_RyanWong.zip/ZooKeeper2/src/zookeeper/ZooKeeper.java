/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zookeeper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class ZooKeeper extends Application {

    private static final String D_SNHU_IT_145_ANIMALS = "animals_File/animals.txt";
    private static final String ANIMALS_FILE = D_SNHU_IT_145_ANIMALS;// name of animals information file
    private static final String HABITATS_FILE = "animals_File/habitats.txt"; // name of the habitats information file
    private static final String HABITATS_FILE2 = HABITATS_FILE;

    @Override
    public void start(Stage primaryStage) {

        VBox mainbox = new VBox();

        mainbox.setPadding(new Insets(30, 40, 20, 70));
        HBox.setHgrow(mainbox, Priority.ALWAYS);
        mainbox.setAlignment(Pos.TOP_CENTER);
        mainbox.setSpacing(20);

        Label lbl = new Label("What Would You Like To Do");
        lbl.setStyle("-fx-font: normal bold 16px 'sans-serif' ");
        mainbox.getChildren().add(lbl);

        
        HBox hbox = new HBox();
        HBox.setHgrow(hbox, Priority.ALWAYS);
        hbox.setSpacing(20);
        Button bt1 = new Button("Monitor Animal?");
        Button bt2 = new Button("Monitor Habitat?");
        
        hbox.getChildren().add(bt1);
        hbox.getChildren().add(bt2);

        bt1.setOnAction(e -> {
            displayStageTwo();
            primaryStage.close();
        });
        
         bt2.setOnAction(e -> {
            displayStageThree();
            primaryStage.close();
        });
        mainbox.getChildren().add(hbox);

        Scene scene = new Scene(mainbox, 350, 150);

        primaryStage.setTitle("Zoo Keeper Application!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        launch(args);

    }

    public void displayStageTwo() {
    	
    	
        Stage stagetwo = new Stage();
        VBox mainbox = new VBox();

        mainbox.setPadding(new Insets(30, 40, 20, 70));
        HBox.setHgrow(mainbox, Priority.ALWAYS);
        mainbox.setAlignment(Pos.TOP_CENTER);
        mainbox.setSpacing(20);

        Label lbl = new Label("Which Animal Would You Lie to Monitor");
        lbl.setStyle("-fx-font: normal bold 16px 'sans-serif' ");
        mainbox.getChildren().add(lbl);

        HBox hbox = new HBox();
        hbox.setSpacing(20);
        Button bt1 = new Button("Lion");
        bt1.setPrefWidth(120);
        bt1.setOnAction(e -> {

            showInfoForAnimals("Lion");
        });

        Button bt2 = new Button("Tiger");
        bt2.setPrefWidth(120);
        bt2.setOnAction(e -> {

            showInfoForAnimals("Tiger");
        });
        Button bt3 = new Button("Bear");
        bt3.setPrefWidth(120);
        bt3.setOnAction(e -> {

            showInfoForAnimals("Bear");
        });
        Button bt4 = new Button("Giraffe");
        bt4.setPrefWidth(120);
        bt4.setOnAction(e -> {

            showInfoForAnimals("Giraffe");
        });
        hbox.getChildren().add(bt1);

        hbox.getChildren().add(bt2);
        hbox.getChildren().add(bt3);
        hbox.getChildren().add(bt4);
        mainbox.getChildren().add(hbox);

        HBox box3 = new HBox();
        Button bt5 = new Button("Main Menu");
        box3.getChildren().add(bt5);
        bt5.setOnAction((ActionEvent e) -> {
            start(new Stage());
            stagetwo.close();
        });
        mainbox.getChildren().add(box3);

        Scene scene = new Scene(mainbox, 450, 150);
        stagetwo.setTitle("Zoo Keeper Application!");
        stagetwo.setScene(scene);
        stagetwo.show();

    }

     public void displayStageThree() {

        Stage stagetwo = new Stage();
        VBox mainbox = new VBox();

        mainbox.setPadding(new Insets(30, 40, 20, 70));
        HBox.setHgrow(mainbox, Priority.ALWAYS);
        mainbox.setAlignment(Pos.TOP_CENTER);
        mainbox.setSpacing(20);

        Label lbl = new Label("Which Habitat Would You Like To Monitor");
        lbl.setStyle("-fx-font: normal bold 16px 'sans-serif' ");
        mainbox.getChildren().add(lbl);

        HBox hbox = new HBox();
        hbox.setSpacing(20);
        Button bt1 = new Button("Penguin");
        bt1.setPrefWidth(120);
        bt1.setOnAction(e -> {

            showInfoForHabitats("Penguin");
        });

        Button bt2 = new Button("Bird");
        bt2.setPrefWidth(120);
        bt2.setOnAction(e -> {

            showInfoForHabitats("Bird");
        });
        
        Button bt3 = new Button("Aquarium");
        bt3.setPrefWidth(120);
        bt3.setOnAction(e -> {

            showInfoForHabitats("Aquarium");
        });
        
        hbox.getChildren().add(bt1);
        hbox.getChildren().add(bt2);
        hbox.getChildren().add(bt3);
        mainbox.getChildren().add(hbox);

        HBox box3 = new HBox();
        Button bt5 = new Button("Main Menu");
        box3.getChildren().add(bt5);
        bt5.setOnAction((ActionEvent e) -> {
            start(new Stage());
            stagetwo.close();
        });
        mainbox.getChildren().add(box3);

        Scene scene = new Scene(mainbox, 450, 150);
        stagetwo.setTitle("Zoo Keeper Application!");
        stagetwo.setScene(scene);
        stagetwo.show();

    }

    /**
     * @param selectedAnimal - animal name will be passed as a parameter
     */
    public void showInfoForAnimals(String selectedAnimal) {
        File file = new File(ANIMALS_FILE);
        BufferedReader br = null;
        String line = "";
        int lines = 0;
        try {

            // to read the contents from the file
            br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null) {
                if (lines == 1 || lines == 2 || lines == 3 || lines == 4) {
                    //this condition will display the next four lines from the file when the animal name get matched
                    lines++;

                    if (line.startsWith("*")) { //if the warning message is found replaces the asterisks from the warning message
                        alertUser(line.replaceAll("\\*", ""));
                    }

                    alertUser(line);

                }
                if (lines >= 5) {

                    lines = 0;
                    break;
                }
                if (line.trim().equalsIgnoreCase("ANIMAL - " + selectedAnimal)) {
                    // to check whether the entered animal matches with the animal name present in the file
                    lines++;
                }
            }
        } catch (FileNotFoundException e) {

            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        } finally {
            if (br != null) {
                try {
                    br.close(); // br closed
                } catch (IOException e) {
                    System.out.println(e);
                }
            }
        }
    }

    /**
     * @param message - to pass the warning message from the file method to
     * alert the user if any warning is found in the file
     */
    public void alertUser(String message) {

        Dialog<String> dialog = new Dialog<>();
        //JDialog is used to show the dialogue on the top of the console window once the warning is noticed from the file

        //Setting the title
        dialog.setTitle("Zoo application");
        ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
        //Setting the content of the dialog
        dialog.setContentText(message);
        //Adding buttons to the dialog pane
        dialog.getDialogPane().getButtonTypes().add(type);

        dialog.showAndWait();

    }
    
    
    /**
     * @param selectedHabitat will be passed as a parameter
     */
    public void showInfoForHabitats(String selectedHabitat) {
        File file = new File(HABITATS_FILE2);
        BufferedReader br = null;
        String line = "";
        int lines = 0;
        try {
// to read the contents from the file
            br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null) {
                if (lines == 1 || lines == 2 || lines == 3) {//this condition will display the next three lines from the file when the habitat name get matched
                    lines++;
                    if (line.startsWith("*")) {//if the warning message is found replaces the asterisks from the warning message
                        alertUser(line.replaceAll("\\*", ""));
                    }
                    alertUser(line);
                }
                if (lines >= 4) {
                    lines = 0;
                    
                }

                //trim method is used to remove the space
                if (line.trim().equalsIgnoreCase("Habitat - " + selectedHabitat)) { // to check whether the entered animal matches with the habitat name present in the file
                    lines++;
                }
            }
        } catch (FileNotFoundException e) {
             System.out.println(e);
        } catch (IOException e) {
             System.out.println(e);
        } finally {
            if (br != null) {
                try {
                    br.close(); //br closed
                } catch (IOException e) {
                     System.out.println(e);
                }
            }
        }
    }


}
